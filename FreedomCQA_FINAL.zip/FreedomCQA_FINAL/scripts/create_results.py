"""Create official JSON without opening the browser.

Example:
  py scripts/create_results.py --kind prod --group CONTROL_GROUP --team "My Team"
"""
import argparse
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import build_organizer_submission
from submission import SubmissionError


def main():
    parser=argparse.ArgumentParser(description='Freedom Broker results.json 1.0 generator')
    parser.add_argument('--kind',choices=['dev','prod'],required=True)
    parser.add_argument('--group',required=True,help='dataset_group_id from organizers API, DEV or control value')
    parser.add_argument('--team',required=True,help='registered team name')
    parser.add_argument('--checklist-id',default=None,help='optional rubric version, e.g. checklist-v2')
    args=parser.parse_args()
    try:
        report=build_organizer_submission(args.kind,args.group,args.team,args.checklist_id)
    except SubmissionError as e:
        print('EXPORT FAILED:',e,file=sys.stderr)
        return 1
    print('EXPORTED:',report['path'])
    print('Records:',report['report']['total'],'OK:',report['report']['ok'],'ERROR:',report['report']['error'])
    print('Model:',report['model']['mode'],'/',report['model']['name'])
    if report['warnings']:
        for w in report['warnings'][:8]: print('WARNING:',w)
    if report['report']['error']:
        print('WARNING: Some conversations are status=error; inspect before committing.')
    return 0

if __name__=='__main__':raise SystemExit(main())
