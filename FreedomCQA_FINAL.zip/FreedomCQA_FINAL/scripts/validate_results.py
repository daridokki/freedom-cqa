"""Preflight submission file against the original transcripts and current SQLite DB.

Example:
 py scripts/validate_results.py --kind dev --group DEV --checklist-id checklist-v1
"""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app import db_conn,get_checklist,ROOT
from submission import validate_document,SubmissionError


def main():
    p=argparse.ArgumentParser(description='Check Freedom CQA results.json 1.0 before push')
    p.add_argument('--kind',choices=['dev','prod'],required=True)
    p.add_argument('--group',help='source dataset_group_id; auto-detect by exact ID match if omitted')
    p.add_argument('--checklist-id',default=None)
    args=p.parse_args()
    path=ROOT/'results'/args.kind/'results.json'
    if not path.exists():
        print('MISSING:',path,file=sys.stderr);return 1
    try:
        doc=json.loads(path.read_text(encoding='utf-8'))
        ids_in_file={r['conversation_id'] for r in doc['results']}
        with db_conn() as db:
            groups=[r[0] for r in db.execute("SELECT DISTINCT dataset_group_id FROM conversations WHERE dataset_group_id!='demo'")]
            matching=[]
            for group in groups:
                rows=list(db.execute('SELECT id,transcript_json FROM conversations WHERE dataset_group_id=?',(group,)))
                if {r['id'] for r in rows}==ids_in_file and len(rows)==(65 if args.kind=='dev' else 10):
                    matching.append((group,rows))
            if args.group:
                rows=list(db.execute('SELECT id,transcript_json FROM conversations WHERE dataset_group_id=?',(args.group,)))
                if not rows:raise SubmissionError('Dataset group not found in SQLite: '+args.group)
                group=args.group
            else:
                if len(matching)!=1:
                    raise SubmissionError('Cannot uniquely infer dataset group; pass --group')
                group,rows=matching[0]
            rubric=get_checklist(db,args.checklist_id)
            evidence={r['id']:json.loads(r['transcript_json']) for r in rows}
            result=validate_document(doc,[r['id'] for r in rows],evidence,rubric)
        print('VALIDATED:',str(path),'group:',group)
        print('TOTAL:',result['total'],'OK:',result['ok'],'ERROR:',result['error'])
        if result['total']!=(65 if args.kind=='dev' else 10):
            raise SubmissionError('Wrong count for kind')
        if result['error']:
            print('WARNING: Export contains status=error; consider resolving before Git push.')
        return 0
    except (SubmissionError,KeyError,TypeError,ValueError,json.JSONDecodeError) as e:
        print('INVALID:',e,file=sys.stderr);return 1

if __name__=='__main__':raise SystemExit(main())
