"""Validate organizer PROD JSON against the exact downloaded FBroker source IDs.

Usage (PowerShell):
  py scripts/last_hour_preflight.py --dataset FBroker_10_Import.json --results results/prod/results.json

Zero exit code only when every control chat has a valid `ok` assessment.
"""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from submission import validate_document, SubmissionError


def run():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dataset',required=True)
    parser.add_argument('--results',default='results/prod/results.json')
    args=parser.parse_args()
    try:
        source=json.loads(Path(args.dataset).read_text(encoding='utf-8-sig'))
        data=source.get('data',source)
        if data.get('dataset_group_id')!='FBroker':
            raise SubmissionError('PROD only: dataset_group_id must equal FBroker; never use Swap')
        rec=data.get('records',[])
        if len(rec)!=10 or data.get('total_records')!=10:
            raise SubmissionError('Expected exactly 10 original FBroker records')
        ids=[r['conversation_id'] for r in rec]
        transcripts={r['conversation_id']:r['transcript'] for r in rec}
        doc=json.loads(Path(args.results).read_text(encoding='utf-8-sig'))
        report=validate_document(doc,ids,transcripts)
        print('VALID SCHEMA:',report['valid'])
        print('FBroker IDs:',report['total'],'OK:',report['ok'],'ERROR:',report['error'])
        print('MODEL:',doc['model']['mode'],doc['model']['name'])
        for result in doc['results']:
            if result['status']=='error':
                print('UNSCORED:',result['conversation_id'], result.get('error',''))
        if report['error']:
            print('NOT READY: one or more dialogs have status=error. Score them before push.',file=sys.stderr)
            return 2
        print('READY FOR PROD PUSH: exactly 10 evaluated FBroker chats.')
        return 0
    except (OSError,ValueError,KeyError,TypeError,SubmissionError) as exc:
        print('VALIDATION FAILED:',exc,file=sys.stderr)
        return 1


if __name__=='__main__':
    raise SystemExit(run())
