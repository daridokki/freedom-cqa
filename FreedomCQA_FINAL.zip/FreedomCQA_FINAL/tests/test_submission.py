"""Offline organizer JSON 1.0 contract tests. No model/API calls."""
import copy
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from fastapi.testclient import TestClient
import app as api
from scoring import rubric_score
from submission import (OFFICIAL_IDS,SubmissionError,checklist_shape,
                        convert_saved_evaluation,validate_document)


class SubmissionTests(unittest.TestCase):
    def setUp(self):
        self.env=patch.dict(os.environ,{'CQA_LLM_API_KEY':'','CQA_LLM_MODEL':''})
        self.env.start()
        self.temp=tempfile.TemporaryDirectory()
        self.old_db=api.DB
        self.old_root=api.ROOT
        api.DB=Path(self.temp.name)/'cqa.sqlite3'
        api.ROOT=Path(self.temp.name)
        api.init_db()
        self.client=TestClient(api.app)
        self.turns=[{'timestamp':'00:01','speaker':'client','text':'Здравствуйте, тариф где?'},
                    {'timestamp':'00:02','speaker':'operator','text':'Здравствуйте, я Алина. Тариф в веб-кабинете.'}]
        self.import_group('DEV',65)
        self.rubric=self.client.get('/api/state').json()['current_checklist']

    def tearDown(self):
        api.ROOT=self.old_root
        api.DB=self.old_db
        self.temp.cleanup()
        self.env.stop()

    def import_group(self,group,count):
        payload={'isSuccess':True,'data':{'dataset_group_id':group,'total_records':count,
            'records':[{'conversation_id':f'{group.lower()}-{i:03d}', 'language':'RU',
                        'channel':'voice call' if group=='DEV' and i>60 else 'agent chat','transcript':self.turns,'audio_url':None}
                       for i in range(1,count+1)]}}
        r=self.client.post('/api/import/json',json={'payload':payload})
        self.assertEqual(r.status_code,200,r.text)

    def saved(self,cid='dev-001',version='checklist-v1',scalefour=20,mode='llm'):
        rubric=self.rubric
        answers=[]
        for c in rubric['criteria']:
            answer=('no' if c['type']=='flag' else scalefour if c['id']=='04' else
                    max(c['levels']) if c['type']=='scale' else
                    'na' if c['id'] in ('02','03') else 'yes')
            answers.append({'criterion_id':c['id'],'answer':answer,
                            'reason':'Основание: проверена реплика клиента и ответ оператора.',
                            'evidence_indices':[0,1]})
        score=rubric_score(rubric,answers)
        score['model_info']={'model':'qwen-test', 'provider':'openai_compatible'}
        return api.store_evaluation(cid,version,mode,score)

    def export(self,kind='dev',group='DEV',version='checklist-v1'):
        return self.client.post('/api/submissions/build',json={
            'kind':kind,'dataset_group_id':group,'team_name':'Команда Алгоритм',
            'checklist_id':version})

    def test_one_saved_rest_explicit_errors_and_utf8(self):
        self.saved()
        resp=self.export()
        self.assertEqual(resp.status_code,200,resp.text)
        self.assertEqual(resp.json()['report'],{'total':65,'ok':1,'error':64,'valid':True})
        path=api.ROOT/'results/dev/results.json'
        self.assertTrue(path.is_file())
        content=path.read_text('utf-8')
        self.assertIn('Команда Алгоритм',content)
        doc=json.loads(content)
        self.assertEqual(list(doc),['schema_version','team_name','model','results'])
        self.assertEqual(doc['model'],{'mode':'external_api','name':'qwen-test'})
        self.assertEqual(doc['results'][0]['conversation_id'],'dev-001')
        self.assertEqual(doc['results'][0]['status'],'ok')
        self.assertEqual(doc['results'][0]['criteria'][0]['evidence_turns'],[1,2])
        self.assertEqual([c['criterion_id'] for c in doc['results'][0]['criteria']],OFFICIAL_IDS)
        self.assertIs(doc['results'][0]['criteria'][0]['value'],True)
        self.assertIsNone(doc['results'][0]['criteria'][1]['value'])
        self.assertEqual(doc['results'][0]['score']['final_score'],100)
        self.assertEqual(doc['results'][1]['status'],'error')
        self.assertIsNone(doc['results'][1]['score'])
        self.assertEqual(doc['results'][1]['criteria'],[])
        self.assertEqual(self.client.get('/api/submissions/dev/download').status_code,200)

    def test_all_65_ok_scoring_85_38_with_na(self):
        for i in range(1,66): self.saved(f'dev-{i:03d}',scalefour=15)
        resp=self.export()
        self.assertEqual(resp.status_code,200,resp.text)
        self.assertEqual(resp.json()['report']['ok'],65)
        self.assertEqual(resp.json()['report']['error'],0)
        data=json.loads((api.ROOT/'results/dev/results.json').read_text('utf8'))
        # Consultation=15 / 20, dialogue=10/10; with discovery/ID N/A:
        # earned=10+15+15+15+5=60 / available=65 => 92.31.
        self.assertAlmostEqual(data['results'][0]['score']['final_score'],92.31)
        self.assertEqual(data['results'][0]['criteria'][3]['value'],15)

    def test_prod_control_10_and_no_leak_from_dev(self):
        self.import_group('CONTROL-AB',10)
        self.saved('control-ab-001')
        r=self.export('prod','CONTROL-AB')
        self.assertEqual(r.status_code,200,r.text)
        doc=json.loads((api.ROOT/'results/prod/results.json').read_text('utf8'))
        self.assertEqual(len(doc['results']),10)
        self.assertTrue(all(x['conversation_id'].startswith('control-ab-') for x in doc['results']))
        self.assertTrue((api.ROOT/'results/prod/results.json').is_file())
        self.assertFalse((api.ROOT/'results/dev/results.json').exists())

    def test_archive_does_not_drop_original_id(self):
        self.assertEqual(self.client.post('/api/conversations/dev-003/archive').status_code,200)
        r=self.export()
        self.assertEqual(r.status_code,200,r.text)
        doc=json.loads((api.ROOT/'results/dev/results.json').read_text('utf8'))
        self.assertIn('dev-003',{x['conversation_id'] for x in doc['results']})

    def test_wrong_count_blocks_file(self):
        r=self.export('prod','DEV')
        self.assertEqual(r.status_code,422)
        self.assertFalse((api.ROOT/'results/prod/results.json').exists())
        r=self.export('dev','NO-SUCH')
        self.assertEqual(r.status_code,422)

    def test_renamed_or_ninth_criterion_not_silently_mapped(self):
        bad=copy.deepcopy(self.rubric)
        bad['criteria'][0]['id']='greeting'
        with self.assertRaises(SubmissionError): checklist_shape(bad)
        bad=copy.deepcopy(self.rubric)
        bad['criteria'].append(copy.deepcopy(bad['criteria'][0]))
        with self.assertRaises(SubmissionError): checklist_shape(bad)

    def test_bad_result_types_are_rejected(self):
        self.saved()
        self.export()
        d=json.loads((api.ROOT/'results/dev/results.json').read_text('utf8'))
        d['results'][0]['criteria'][0]['value']=None
        with self.assertRaisesRegex(SubmissionError,'contact'):
            validate_document(d,[f'dev-{i:03d}' for i in range(1,66)])
        d['results'][0]['criteria'][0]['value']=True
        d['results'][0]['criteria'][5]['value']=True
        with self.assertRaisesRegex(SubmissionError,'dialogue'):
            validate_document(d,[f'dev-{i:03d}' for i in range(1,66)])

    def test_score_flag_and_evidence_checked(self):
        self.saved()
        self.export()
        doc=json.loads((api.ROOT/'results/dev/results.json').read_text('utf8'))
        ids=[f'dev-{i:03d}' for i in range(1,66)]
        doc['results'][0]['criteria'][0]['evidence_turns']=[0]
        with self.assertRaisesRegex(SubmissionError,'evidence'):
            validate_document(doc,ids)
        doc['results'][0]['criteria'][0]['evidence_turns']=[1]
        doc['results'][0]['score']['critical_flag']=True
        with self.assertRaisesRegex(SubmissionError,'critical_flag'):
            validate_document(doc,ids)

    def test_duplicate_id_and_missing_rows_rejected(self):
        self.export()
        doc=json.loads((api.ROOT/'results/dev/results.json').read_text('utf8'))
        ids=[f'dev-{i:03d}' for i in range(1,66)]
        doc['results'][1]['conversation_id']=doc['results'][0]['conversation_id']
        with self.assertRaises(SubmissionError): validate_document(doc,ids)
        doc['results']=doc['results'][:-1]
        with self.assertRaises(SubmissionError): validate_document(doc,ids)

    def test_final_after_appeal_instead_of_original(self):
        eid=self.saved()
        appeal=self.client.post('/api/appeals',json={
            'evaluation_id':eid,'criterion_id':'01','comment':'Отсутствовало приветствие'}).json()['appeal_id']
        r=self.client.post(f'/api/appeals/{appeal}/decision',json={
            'decision':'change','answer':'no','reviewer_note':'Приветствие не подтверждается'} )
        self.assertEqual(r.status_code,200,r.text)
        self.export()
        doc=json.loads((api.ROOT/'results/dev/results.json').read_text('utf8'))
        self.assertIs(doc['results'][0]['criteria'][0]['value'],False)
        self.assertAlmostEqual(doc['results'][0]['score']['final_score'],84.62)

    def test_selected_checklist_version_not_stale_other(self):
        self.saved()
        config={'name':'Changed closure wording','criteria':copy.deepcopy(self.rubric['criteria'])}
        config['criteria'][6]['rule']='Да: оператор попрощался.'
        added=self.client.post('/api/checklists',json=config)
        self.assertEqual(added.status_code,200)
        r=self.export(version=added.json()['id'])
        self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(r.json()['report']['error'],65)

if __name__=='__main__':unittest.main()
