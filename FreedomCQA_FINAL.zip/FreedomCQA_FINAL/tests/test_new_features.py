"""Regression tests for v1.1 archive, deletion, group filtering, audits and scoring."""
import json
import os
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from fastapi.testclient import TestClient
import app as module
from checklist import DEFAULT_CHECKLIST
from scoring import rubric_score
from quality import evidence_warnings, score_signature
from llm import independently_audit_evaluation


def make_answers(rubric, first='yes'):
    entries=[]
    for c in rubric['criteria']:
        ans=('no' if c['type']=='flag' else max(c['levels']) if c['type']=='scale'
             else first if c['id']=='01' else 'yes')
        entries.append({'criterion_id':c['id'],'answer':ans,
                        'reason':'Оценка основана на явной реплике оператора и запросе клиента.',
                        'evidence_indices':[0,1]})
    return entries


class FeaturesTest(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.db_prev=module.DB
        module.DB=Path(self.temp.name)/'db.sqlite'
        module.init_db()
        self.client=TestClient(module.app)
        self.dialog={'conversation_id':'qa-ru-001','channel':'agent chat','language':'RU',
                     'transcript':[{'timestamp':'00:00','speaker':'client','text':'Где взять тариф?'},
                                   {'timestamp':'00:03','speaker':'operator','text':'Здравствуйте! Я Анна. Кабинет.'},
                                   {'timestamp':'00:08','speaker':'client','text':'Спасибо!'},
                                   {'timestamp':'00:12','speaker':'operator','text':'До свидания.'}],
                     'audio_url':None}
        self.client.post('/api/import/json',json={'payload':{'data':{
            'dataset_group_id':'DEV','records':[self.dialog]}}}).raise_for_status()
        self.checklist=self.client.get('/api/state').json()['current_checklist']

    def tearDown(self):
        module.DB=self.db_prev
        self.temp.cleanup()

    def make_score(self):
        response=self.client.post('/api/evaluations/manual',json={'conversation_id':'qa-ru-001',
            'answers':make_answers(self.checklist)})
        self.assertEqual(response.status_code,200,response.text)
        return response.json()['evaluation_id']

    def test_demo_excluded_analytics_even_with_existing_evaluation(self):
        eid=self.make_score()
        demo=self.client.post('/api/demo')
        self.assertEqual(demo.status_code,200,demo.text)
        base=self.client.get('/api/analytics').json()
        self.assertEqual(base['evaluations'],1)
        self.assertEqual(base['conversations'],1)
        self.assertEqual(self.client.get('/api/analytics?group_id=DEV').json()['evaluations'],1)
        self.assertEqual(self.client.get('/api/analytics?group_id=demo').json()['evaluations'],1)
        self.assertIn('qa-ru-001',self.client.get('/api/export/results.csv').text)
        self.assertNotIn('demo-ru-001',self.client.get('/api/export/results.csv').text)
        self.assertIn('demo-ru-001',self.client.get('/api/export/results.csv?group_id=demo').text)
        self.assertEqual(self.client.get('/api/evaluations/'+eid).status_code,200)

    def test_archive_restore_delete_with_confirmation_and_backups(self):
        eid=self.make_score()
        appealed=self.client.post('/api/appeals',json={'evaluation_id':eid,
            'criterion_id':'01','comment':'Нужно перепроверить'}).json()['appeal_id']
        url='/api/conversations/qa-ru-001'
        backup=self.client.get(url+'/backup.json').json()
        self.assertEqual(len(backup['evaluations']),1)
        self.assertEqual(len(backup['evaluations'][0]['appeals']),1)
        archived=self.client.post(url+'/archive')
        self.assertEqual(archived.status_code,200,archived.text)
        self.assertEqual(self.client.get('/api/analytics').json()['evaluations'],0)
        self.assertEqual(self.client.get('/api/state').json()['conversations'][0]['archived_at'] is not None,True)
        # Archived dialog cannot be rated, original grades still available.
        self.assertEqual(self.client.post('/api/evaluations',json={'conversation_id':'qa-ru-001'}).status_code,409)
        self.assertEqual(self.client.get('/api/evaluations/'+eid).status_code,200)
        self.assertEqual(self.client.post(url+'/restore').status_code,200)
        self.assertEqual(self.client.get('/api/analytics').json()['evaluations'],1)
        self.assertEqual(self.client.delete(url+'?confirm_id=other&cascade=true').status_code,422)
        self.assertEqual(self.client.delete(url+'?confirm_id=qa-ru-001').status_code,409)
        deleted=self.client.delete(url+'?confirm_id=qa-ru-001&cascade=true')
        self.assertEqual(deleted.status_code,200,deleted.text)
        self.assertEqual(deleted.json()['evaluations_deleted'],1)
        self.assertEqual(self.client.get(url).status_code,404)
        self.assertEqual(self.client.get('/api/evaluations/'+eid).status_code,404)
        with module.db_conn() as db:
            self.assertIsNone(db.execute('SELECT * FROM appeals WHERE id=?',(appealed,)).fetchone())

    def test_audit_is_separate_and_stales_after_appeal(self):
        eid=self.make_score()
        detail=self.client.get('/api/evaluations/'+eid).json()
        original=detail['original']['total_score']
        checks=[]
        for c in detail['checklist']['criteria']:
            checks.append({'criterion_id':c['id'],'supported':False if c['id']=='06' else True,
                 'issue':'Проверка ссылки на подтверждающую реплику и правильность N/A.',
                 'suggested_answer':'no' if c['id']=='06' else 'yes',
                 'evidence_indices':[0,1]})
        with patch.object(module,'independently_audit_evaluation',return_value={
            'checks':checks,'model':'mock-auditor','prompt_tokens':42,'completion_tokens':64}):
            r=self.client.post('/api/evaluations/'+eid+'/audit')
        self.assertEqual(r.status_code,200,r.text)
        after=self.client.get('/api/evaluations/'+eid).json()
        self.assertEqual(after['final']['total_score'],original)
        self.assertIsNotNone(after['audit'])
        self.assertFalse(after['audit_stale'])
        aid=self.client.post('/api/appeals',json={'evaluation_id':eid,'criterion_id':'01',
            'comment':'Не согласен'}).json()['appeal_id']
        decision=self.client.post('/api/appeals/'+aid+'/decision',json={
            'decision':'change','reviewer_note':'Ошибка в приветствии','answer':'no','evidence_indices':[1]})
        self.assertEqual(decision.status_code,200,decision.text)
        changed=self.client.get('/api/evaluations/'+eid).json()
        self.assertTrue(changed['audit_stale'])
        self.assertEqual(changed['original']['total_score'],original)
        self.assertNotEqual(changed['final']['total_score'],original)

    def test_active_job_prevents_delete_archive(self):
        with module.db_conn() as db:
            db.execute('INSERT INTO batch_jobs (id,status,checklist_id,created_at,updated_at,total,completed,succeeded,failed,ids_json,errors_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
                       ('job-a','running','checklist-v1',module.now(),module.now(),1,0,0,0,json.dumps(['qa-ru-001']),'[]'))
        self.assertEqual(self.client.post('/api/conversations/qa-ru-001/archive').status_code,409)
        self.assertEqual(self.client.delete('/api/conversations/qa-ru-001?confirm_id=qa-ru-001&cascade=true').status_code,409)

    def test_batch_does_not_queue_demo_or_archive(self):
        self.client.post('/api/demo')
        self.client.post('/api/conversations/qa-ru-001/archive')
        with patch.dict(os.environ,{'CQA_LLM_API_KEY':'fake','CQA_LLM_MODEL':'fake'}):
            r=self.client.post('/api/jobs/batch',json={})
        self.assertEqual(r.status_code,200,r.text)
        self.assertEqual(r.json()['total'],0)

    def test_heuristic_flags_context_not_score(self):
        # AI said N/A without citing the client, and double-penalized content.
        items=make_answers(self.checklist)
        for x in items:
            if x['criterion_id']=='02':x.update(answer='na',evidence_indices=[1])
            if x['criterion_id']=='06':x.update(answer=4,reason='Оператор не дал ответ по существу.')
        sc=rubric_score(self.checklist,items)
        warnings=evidence_warnings(self.dialog,self.checklist,sc)
        codes={w['code'] for w in warnings}
        self.assertIn('NA_CONTEXT',codes)
        self.assertIn('DOUBLE_PENALTY',codes)
        self.assertIsInstance(score_signature(sc),str)

    def test_existing_database_schema_upgrades_preserve_dialog(self):
        # Create legacy conversations table without archived_at.
        legacy=Path(self.temp.name)/'legacy.sqlite'
        with sqlite3.connect(legacy) as db:
            db.execute('CREATE TABLE conversations (id TEXT PRIMARY KEY, channel TEXT NOT NULL, language TEXT NOT NULL, transcript_json TEXT NOT NULL,audio_url TEXT,created_at TEXT NOT NULL,dataset_group_id TEXT NOT NULL DEFAULT \'manual\')')
            db.execute('INSERT INTO conversations VALUES (?,?,?,?,?,?,?)',('existing','agent chat','RU',json.dumps(self.dialog['transcript']),None,module.now(),'DEV'))
        module.DB=legacy
        module.init_db()
        with module.db_conn() as db:
            self.assertEqual(db.execute('SELECT id FROM conversations').fetchone()[0],'existing')
            self.assertIn('archived_at',{r[1] for r in db.execute('PRAGMA table_info(conversations)')})
            self.assertIn('audit_json',{r[1] for r in db.execute('PRAGMA table_info(evaluations)')})
        module.DB=Path(self.temp.name)/'db.sqlite'


class SemanticAuditMockTests(unittest.TestCase):
    def test_audit_validates_structured_secondary_response(self):
        dialog={'transcript':[{'speaker':'client','timestamp':'00:00','text':'Как найти тариф?'},
                              {'speaker':'operator','timestamp':'00:02','text':'Здравствуйте, я Анна. Смотрите кабинет.'}],
                'language':'RU','channel':'agent chat'}
        grade=rubric_score(DEFAULT_CHECKLIST,make_answers(DEFAULT_CHECKLIST))
        checks=[]
        for c in DEFAULT_CHECKLIST['criteria']:
            ans='no' if c['type']=='flag' else max(c['levels']) if c['type']=='scale' else 'yes'
            checks.append({'criterion_id':c['id'],'supported':c['id']!='06',
                 'issue':'Указано обоснование со ссылкой на реальную реплику.',
                 'suggested_answer':ans,'evidence_indices':[0,1]})
        response=json.dumps({'checks':checks},ensure_ascii=False)
        env={'CQA_LLM_API_KEY':'mock','CQA_LLM_MODEL':'mock-model','CQA_LLM_PROVIDER':'gemini_native',
             'CQA_LLM_FALLBACK_MODELS':'','CQA_LLM_JSON_MODE':'1'}
        with patch.dict(os.environ,env):
            with patch('llm._provider_request',return_value=(response,75,20,'mock-model')):
                result=independently_audit_evaluation(dialog,DEFAULT_CHECKLIST,grade)
        self.assertEqual(len(result['checks']),8)
        self.assertFalse(result['checks'][5]['supported'])
        self.assertEqual(result['model'],'mock-model')
        self.assertIn('human',result['notice'])


if __name__=='__main__':unittest.main()
