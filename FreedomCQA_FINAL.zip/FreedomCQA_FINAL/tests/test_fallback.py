"""Offline fallback behavior; deliberately no external Gemini requests."""
import json
import os
from pathlib import Path
from unittest import TestCase
from unittest.mock import MagicMock, patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from checklist import DEFAULT_CHECKLIST
from llm import evaluate_with_llm, LLMError


def grade_response():
    out=[]
    for c in DEFAULT_CHECKLIST['criteria']:
        answer = 'no' if c['type']=='flag' else max(c['levels']) if c['type']=='scale' else 'na' if c['id']=='03' else 'yes'
        out.append({'criterion_id':c['id'],'answer':answer,'reason':'Оператор корректно отвечает на запрос клиента.','evidence_indices':[0,1]})
    return {'candidates':[{'content':{'parts':[{'text':json.dumps({'results':out},ensure_ascii=False)}]}}]}


def response(status, data):
    r=MagicMock();r.status_code=status;r.headers={};r.json.return_value=data
    return r

class FallbackTests(TestCase):
    def setUp(self):
        self.dialog={'language':'RU','channel':'agent chat','transcript':[
            {'timestamp':'00:00','speaker':'client','text':'Где тариф?'},
            {'timestamp':'00:10','speaker':'operator','text':'Здравствуйте, я Лена. Тариф в кабинете.'}]}
        self.env={'CQA_LLM_PROVIDER':'gemini_native','CQA_LLM_API_KEY':'fake',
                  'CQA_LLM_MODEL':'primary-test-model','CQA_LLM_FALLBACK_MODELS':'backup-test-model',
                  'CQA_LLM_HTTP_RETRIES':'0','CQA_LLM_JSON_MODE':'1'}

    def mocked(self, answers):
        c=MagicMock();c.post.side_effect=list(answers)
        cm=MagicMock();cm.__enter__.return_value=c
        return c,cm

    def test_503_switches_to_fallback_and_preserves_model_provenance(self):
        c,cm=self.mocked([response(503,{'error':{'status':'UNAVAILABLE','message':'high demand'}}),
                         response(200,grade_response())])
        with patch.dict(os.environ,self.env):
            with patch('llm.httpx.Client',return_value=cm):
                scored=evaluate_with_llm(self.dialog,DEFAULT_CHECKLIST)
        self.assertEqual(scored['total_score'],100)
        self.assertEqual(scored['model_info']['model'],'backup-test-model')
        self.assertTrue(scored['model_info']['fallback_used'])
        self.assertEqual(c.post.call_count,2)
        self.assertIn('primary-test-model',c.post.call_args_list[0].args[0])
        self.assertIn('backup-test-model',c.post.call_args_list[1].args[0])

    def test_400_does_not_try_other_models(self):
        c,cm=self.mocked([response(400,{'error':{'status':'INVALID_ARGUMENT','message':'bad request'}})])
        with patch.dict(os.environ,self.env):
            with patch('llm.httpx.Client',return_value=cm):
                with self.assertRaisesRegex(LLMError,'HTTP 400'):
                    evaluate_with_llm(self.dialog,DEFAULT_CHECKLIST)
        self.assertEqual(c.post.call_count,1)

    def test_quota_429_does_not_try_other_models(self):
        c,cm=self.mocked([response(429,{'error':{'status':'RESOURCE_EXHAUSTED','message':'limit'}})])
        with patch.dict(os.environ,self.env):
            with patch('llm.httpx.Client',return_value=cm):
                with self.assertRaisesRegex(LLMError,'temporarily unavailable'):
                    evaluate_with_llm(self.dialog,DEFAULT_CHECKLIST)
        self.assertEqual(c.post.call_count,1)

    def test_all_models_503_clearly_fails(self):
        c,cm=self.mocked([response(503,{'error':{'status':'UNAVAILABLE','message':'busy'}}),
                         response(503,{'error':{'status':'UNAVAILABLE','message':'busy too'}})])
        with patch.dict(os.environ,self.env):
            with patch('llm.httpx.Client',return_value=cm):
                with self.assertRaisesRegex(LLMError,'backup-test-model'):
                    evaluate_with_llm(self.dialog,DEFAULT_CHECKLIST)
        self.assertEqual(c.post.call_count,2)
